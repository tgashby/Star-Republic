//
//  ModelViewerAppDelegate.h
//  ModelViewer
//
//  Created by Taggart Ashby on 1/31/12.
//  Copyright 2012 476 Proj. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ModelViewerAppDelegate : NSObject <NSApplicationDelegate> {
   NSWindow *window;
}

@property (assign) IBOutlet NSWindow *window;

@end
