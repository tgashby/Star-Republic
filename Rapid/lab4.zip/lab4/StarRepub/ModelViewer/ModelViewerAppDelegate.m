//
//  ModelViewerAppDelegate.m
//  ModelViewer
//
//  Created by Taggart Ashby on 1/31/12.
//  Copyright 2012 476 Proj. All rights reserved.
//

#import "ModelViewerAppDelegate.h"

@implementation ModelViewerAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
   // Insert code here to initialize your application
}

@end
