//
//  main.m
//  ModelViewer
//
//  Created by Taggart Ashby on 1/31/12.
//  Copyright 2012 476 Proj. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
   return NSApplicationMain(argc, (const char **)argv);
}
