//
//  StarRepubAppDelegate.h
//  StarRepub
//
//  Created by Taggart Ashby on 1/31/12.
//  Copyright 2012 476 Proj. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface StarRepubAppDelegate : NSObject <NSApplicationDelegate> {
   NSWindow *window;
}

@property (assign) IBOutlet NSWindow *window;

@end
