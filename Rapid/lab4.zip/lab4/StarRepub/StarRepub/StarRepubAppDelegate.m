//
//  StarRepubAppDelegate.m
//  StarRepub
//
//  Created by Taggart Ashby on 1/31/12.
//  Copyright 2012 476 Proj. All rights reserved.
//

#import "StarRepubAppDelegate.h"

@implementation StarRepubAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
   // Insert code here to initialize your application
}

@end
