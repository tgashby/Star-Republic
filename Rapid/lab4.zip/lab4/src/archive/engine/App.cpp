#include "App.h"

App::App(void)
{
}
	
	
App::~App(void)
{
}
