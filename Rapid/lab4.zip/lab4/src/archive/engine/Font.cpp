#include "Font.h"

Font::Font(void)
{
}


Font::~Font(void)
{
}
