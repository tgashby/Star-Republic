#pragma once

class Font
{
public:
   Font(void);
   ~Font(void);
};


