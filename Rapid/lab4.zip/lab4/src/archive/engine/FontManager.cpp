#include "FontManager.h"

FontManager::FontManager(void)
{
}


FontManager::~FontManager(void)
{
}

