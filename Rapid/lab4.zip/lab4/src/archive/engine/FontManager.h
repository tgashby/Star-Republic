#pragma once

class FontManager
{
public:
	FontManager(void);
	~FontManager(void);
};

