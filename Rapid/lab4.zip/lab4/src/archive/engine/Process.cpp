#include "Process.h"

Process::Process(void)
{
}
	
	
Process::~Process(void)
{
}
