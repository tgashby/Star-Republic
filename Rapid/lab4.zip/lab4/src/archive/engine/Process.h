#pragma once

class Process
{
public:
	Process(void);
	~Process(void);
};
