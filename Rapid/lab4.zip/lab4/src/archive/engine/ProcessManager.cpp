#include "ProcessManager.h"

ProcessManager::ProcessManager(void)
{
}
	
	
ProcessManager::~ProcessManager(void)
{
}
