#pragma once

class ProcessManager
{
public:
	ProcessManager(void);
	~ProcessManager(void);
};

