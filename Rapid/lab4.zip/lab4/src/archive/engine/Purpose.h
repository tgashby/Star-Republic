enum Purpose
{

};