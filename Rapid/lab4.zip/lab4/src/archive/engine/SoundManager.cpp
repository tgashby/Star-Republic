#include "SoundManager.h"

SoundManager::SoundManager(void)
{
}
	
	
SoundManager::~SoundManager(void)
{
}
