#pragma once

class SoundManager
{
public:
	SoundManager(void);
	~SoundManager(void);
};

