#include "StateManager.h"

StateManager::StateManager(void)
{
}
	
	
StateManager::~StateManager(void)
{
}
