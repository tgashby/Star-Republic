#pragma once

class StateManager
{
public:
	StateManager(void);
	~StateManager(void);
};

