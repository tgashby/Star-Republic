/**
 * This will eventually be the implementation of the Angle class 
 */
