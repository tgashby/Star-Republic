
class Terrain
{
public:

	int xlocs[], ylocs[];

	Terrain();
	~Terrain();
};

