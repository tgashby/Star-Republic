#include "Camera.h"

#define DEF_DISTANCE 10
#define FLOOR_OFFSET 2

Camera::Camera(vec3 start) {
   m_dist = DEF_DISTANCE;
   m_fwd = vec3(0, 0, m_dist);
   m_eye = start + m_fwd;
   m_ref = start;
   m_up = vec3(0, 1, 0);
   m_pitch = 0;
   m_yaw = 0;
   
   m_planes = vector<vec4>(6);
   
   m_viewPort.lowerLeft = ivec2(0, 0);
   m_viewPort.size = ivec2(800, 600);
   m_viewPort.scissor = false;
   
   // Set the projection matrix
   float h = 4.0f * m_viewPort.size.x / m_viewPort.size.y;
   m_projection = mat4::Frustum(-h / 2, h / 2, -2, 2, 4, 1000);
}

Camera::~Camera() {
   
}

mat4 Camera::getProjectionViewMtx() {
   // apply the view
   mat4 projectionMatrix = mat4::LookAt(m_projection, m_eye, m_ref, m_up);
   
   return projectionMatrix;
}

mat4 Camera::getProjectionMtx() {
   return m_projection;
}

mat4 Camera::getView() {
   return mat4::LookAt(mat4::Identity(), m_eye, m_ref, m_up);
}

vector<vec4>* Camera::getPlanes() {
   mat4 projMtx = mat4::LookAt(m_projection, m_eye, m_ref, m_up);
   
   m_planes[0].x = projMtx.x.w + projMtx.x.x;
   m_planes[0].y = projMtx.y.w + projMtx.y.x;
   m_planes[0].z = projMtx.z.w + projMtx.z.x;
   m_planes[0].w = projMtx.w.w + projMtx.w.x;
   m_planes[0].NormalizePlane();
   
   m_planes[1].x = projMtx.x.w - projMtx.x.x;
   m_planes[1].y = projMtx.y.w - projMtx.y.x;
   m_planes[1].z = projMtx.z.w - projMtx.z.x;
   m_planes[1].w = projMtx.w.w - projMtx.w.x;
   m_planes[1].NormalizePlane();
   
   m_planes[2].x = projMtx.x.w + projMtx.x.y;
   m_planes[2].y = projMtx.y.w + projMtx.y.y;
   m_planes[2].z = projMtx.z.w + projMtx.z.y;
   m_planes[2].w = projMtx.w.w + projMtx.w.y;
   m_planes[2].NormalizePlane();
   
   m_planes[3].x = projMtx.x.w - projMtx.x.y;
   m_planes[3].y = projMtx.y.w - projMtx.y.y;
   m_planes[3].z = projMtx.z.w - projMtx.z.y;
   m_planes[3].w = projMtx.w.w - projMtx.w.y;
   m_planes[3].NormalizePlane();
   
   m_planes[4].x = projMtx.x.w + projMtx.x.z;
   m_planes[4].y = projMtx.y.w + projMtx.y.z;
   m_planes[4].z = projMtx.z.w + projMtx.z.z;
   m_planes[4].w = projMtx.w.w + projMtx.w.z;
   m_planes[4].NormalizePlane();
   
   m_planes[5].x = projMtx.x.w - projMtx.x.z;
   m_planes[5].y = projMtx.y.w - projMtx.y.z;
   m_planes[5].z = projMtx.z.w - projMtx.z.z;
   m_planes[5].w = projMtx.w.w - projMtx.w.z;
   m_planes[5].NormalizePlane();
   
   return &m_planes;
}

ViewPort Camera::getViewPort() {
   return m_viewPort;
}

vec3 Camera::getEyeLoc() {
   return m_eye;
}

void Camera::moveInOut(float dist) {
   m_dist += dist * 2;
   if (m_dist < 1.0) {
      m_dist = 1;
   }
   rotLocal(0, 0);
}

vec3 Camera::getLoc() {
   return m_ref;
}

vec3 Camera::getDir() {
   return m_fwd;
}

void Camera::rotLocal(float pitch, float yaw) {
   m_pitch += pitch;
   m_yaw += yaw;
   
   if (m_pitch > 80)
      m_pitch = 80;
   else if (m_pitch < -80)
      m_pitch = -80;
   
   if (m_yaw >= 360)
      m_yaw -= 360;
   else if (m_yaw < 0)
      m_yaw += 360;
   
   mat4 rot = mat4::Rotate(-m_pitch, vec3(1,0,0));
   rot = rot * mat4::Rotate(m_yaw, vec3(0,1,0));
   vec4 d = rot.TranslatePoint(vec4(0, 0, m_dist, 0));
   m_fwd = vec3(d.x, d.y, d.z);
   m_eye = m_ref + m_fwd;
}