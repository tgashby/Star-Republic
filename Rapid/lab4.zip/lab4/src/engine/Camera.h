#ifndef StarRepub_Camera_h
#define StarRepub_Camera_h

#include "Interfaces.h"

class Camera: public ICamera {
public:
   Camera(vec3 start);
   ~Camera();
   mat4 getProjectionViewMtx();
   mat4 getProjectionMtx();
   mat4 getView();
   vector<vec4>* getPlanes();
   ViewPort getViewPort();
   vec3 getEyeLoc();
   vec3 getLoc();
   vec3 getDir();
   void rotLocal(float pitch, float yaw);
   void moveInOut(float dist);
private:
   vec3 m_eye;
   vec3 m_ref;
   vec3 m_up;
   vec3 m_fwd;
   float m_pitch, m_yaw, m_dist;
   ViewPort m_viewPort;
   mat4 m_projection;
   vector<vec4> m_planes;
};

#endif
