#include "Object3d.h"
#include "Mesh.h"


Object3d::Object3d(string fileName, string textureName, float scale, Modules *modules) {
   m_meshList = list<IMesh *>(0);
   Mesh *mesh = new Mesh(fileName, textureName, scale, modules);
   m_meshList.push_back(mesh);
}


Object3d::Object3d() {
   m_meshList = list<IMesh *>(0);
}

Object3d::~Object3d() {
   list<IMesh *>::iterator mesh;
   for (mesh = m_meshList.begin(); mesh != m_meshList.end(); ++mesh) {
      delete *mesh;
   }
}

void Object3d::tic(float td) {
   
}

list<IMesh *>* Object3d::getMeshes() {
   return &m_meshList;
}

bool Object3d::isVisible() {
   return true;
}

void Object3d::setVisible(bool vis) {
   // do nothing
}

bool Object3d::isRemove() {
   return false;
}

void Object3d::viewCull(vector<vec4> *planes) {
   // do nothing.
}

BSphere Object3d::getBSphere() {
   BSphere sphere = BSphere();
   sphere.loc = vec3(0, 0, 0);
   sphere.radius = 1;
   return sphere;
}