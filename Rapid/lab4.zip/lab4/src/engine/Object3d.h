#ifndef StarRepub_Object3d_h
#define StarRepub_Object3d_h

#include "Interfaces.h"

class Object3d : public IObject3d {
public:
   Object3d(string fileName, string textureName,
            float scale, Modules *modules);
   Object3d();
   ~Object3d();
   void tic(float td);
   list<IMesh *>* getMeshes();
   bool isVisible();
   void setVisible(bool vis);
   bool isRemove();
   void viewCull(vector<vec4> *planes);
   BSphere getBSphere();
protected:
   list<IMesh *> m_meshList;
};

#endif
