#include "DisplayObj.h"

#include "DisplayObj.h"

#define DisplayObj_SCALE 5

DisplayObj::DisplayObj(string meshFile, string textureFile, Modules *modules) {
   m_meshList = list<IMesh *>(0);
   m_mainMesh = new Mesh(meshFile, textureFile, DisplayObj_SCALE, modules);
   //m_mainMesh->setShaderType(SHADER_VERTEX_LIGHT);
   m_mainMesh->setShaderType(SHADER_FRAG_LIGHT);
   
   m_pitch = m_yaw = 0;
   m_rotation = Quaternion();
   m_mainMesh->setModelMtx(m_rotation.ToMatrix4());
   
   m_meshList.push_back(m_mainMesh);
   m_visible = true;
}

DisplayObj::DisplayObj(string meshFile, string textureFile, string normalFile, Modules *modules) {
   m_meshList = list<IMesh *>(0);
   m_mainMesh = new Mesh(meshFile, textureFile, normalFile, DisplayObj_SCALE, modules);
   m_mainMesh->setShaderType(SHADER_NORMAL_LIGHT);
   
   m_pitch = m_yaw = 0;
   m_rotation = Quaternion();
   m_mainMesh->setModelMtx(m_rotation.ToMatrix4());
   
   m_meshList.push_back(m_mainMesh);
   m_visible = true;
}

DisplayObj::~DisplayObj() {
   list<IMesh *>::iterator mesh;
   for (mesh = m_meshList.begin(); mesh != m_meshList.end(); ++mesh) {
      delete *mesh;
   }
}

void DisplayObj::tic(float td) {
   // The DisplayObj does not move.
}

list<IMesh *>* DisplayObj::getMeshes() {
   return &m_meshList;
}

void DisplayObj::setVisible(bool visible) {
   m_visible = visible;
}

void DisplayObj::setRemove() {
   // The DisplayObj can not be removed.
}

bool DisplayObj::isVisible() {
   return m_visible;
}

bool DisplayObj::isRemove() {
   return false;
}

void DisplayObj::viewCull(vector<vec4> *planes) {
   // Do nothing
}

void DisplayObj::rotate(float pitch, float yaw) {
   Quaternion p = Quaternion::CreateFromAxisAngle(vec3(1, 0, 0), pitch/24.0);
   Quaternion y = Quaternion::CreateFromAxisAngle(vec3(0, 1, 0), -yaw/24.0);
   
   p.Rotate(y);
   p.Rotate(m_rotation);
   m_rotation = p;
   
   mat4 rot = m_rotation.ToMatrix4();
   m_mainMesh->setModelMtx(rot);
}

BSphere DisplayObj::getBSphere() {
   BSphere sphere = BSphere();
   sphere.loc = vec3(0, 0, 0);
   sphere.radius = 1;
   return sphere;
}