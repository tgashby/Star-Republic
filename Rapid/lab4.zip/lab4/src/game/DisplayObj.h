#ifndef BalloonGame_DisplayObj_h
#define BalloonGame_DisplayObj_h

#include "Interfaces.h"
#include "Mesh.h"

class DisplayObj : public IObject3d {
public:
   DisplayObj(string meshFile, string textureFile, Modules *modules);
   DisplayObj(string meshFile, string textureFile, string normalFile, Modules *modules);
   ~DisplayObj();
   void tic(float td);
   list<IMesh *>* getMeshes();
   void setVisible(bool visible);
   void setRemove();
   bool isVisible();
   bool isRemove();
   void viewCull(vector<vec4> *planes);
   void rotate(float pitch, float yaw);
   BSphere getBSphere();
protected:
   list<IMesh *> m_meshList;
   Quaternion m_rotation;
   Mesh *m_mainMesh;
   bool m_visible;
   vec3 m_curLoc;
   vec3 m_leafLoc1;
   float m_pitch;
   float m_yaw;
};

#endif
