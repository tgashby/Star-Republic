#include <sstream>
#include "GameEngine.h"
#include "../engine/Object3d.h"
#include "DisplayObj.h"


GameEngine::GameEngine(Modules *modules) {
   m_modules = modules;
   m_objects = list<IObject3d *>(0);
   
   m_camera = new Camera(vec3(0, 0, 0));
   modules->renderingEngine->setCamera(m_camera);
   
   mouseLeft = mouseMiddle = mouseRight = false;
   moving = true;
   frameCount = 0;
   timeElapsed = 0;
   m_fps = "fps: 60";
   
   //m_displayObj = new DisplayObj("models/Tyra.obj", "textures/gray.bmp", m_modules);
   m_displayObj = new DisplayObj("models/Tyra.obj", "textures/gray.bmp", "textures/TyraNormals.bmp", m_modules);
   m_modules->renderingEngine->addObject3d(m_displayObj);
   m_objects.push_back(m_displayObj);
}


GameEngine::~GameEngine() {
   list<IObject3d *>::iterator object = m_objects.begin();
   for (; object != m_objects.end(); ++object) {
      delete *object;
   }
   m_objects.clear();
   delete m_camera;
}

void GameEngine::tic(unsigned int td) {
   
   // get the frames per second
   timeElapsed += td;
   ++frameCount;
   if (timeElapsed > FPS_UPDATE) {
      float fps = frameCount / (timeElapsed / 1000);
      
      stringstream ss;
      ss << "fps: " << fps;
      m_fps = ss.str();
      
      timeElapsed = 0;
      frameCount = 0;
   }
   
   // move the objects.
   list<IObject3d *>::iterator object = m_objects.begin();
   for (; object != m_objects.end(); ++object) {
      if (moving)
         (*object)->tic(td);
      
      // remove any unneeded objects.
      if ((*object)->isRemove()) {
         //m_modules->renderingEngine->removeObject3d(*object);
         delete *object;
         object = m_objects.erase(object);
      }
   }
   
   
   //cout << "list size: " << m_objects.size() << "\n";
}


void GameEngine::render() {
   m_modules->renderingEngine->render(m_objects);
   m_modules->renderingEngine->drawText(m_fps, ivec2(270, 290), ivec2(200, 50));
}


void GameEngine::handleKeyDown(const char *k) {
   /* not used yet
   switch (*k) {
      case 'w':
      case 'W':
         upkey = true;
         break;
      case 's':
      case 'S': 
         downkey = true;
         break;
      case 'a': 
      case 'A':
         leftkey = true;
         break;
      case 'd':
      case 'D': 
         rightkey = true;
         break;
   }*/
}

void GameEngine::handleKeyUp(const char *k) {
   /* not used yet
   switch (*k) {
      case 'w':
      case 'W':
         upkey = false;
         break;
      case 's':
      case 'S': 
         downkey = false;
         break;
      case 'a': 
      case 'A':
         leftkey = false;
         break;
      case 'd':
      case 'D': 
         rightkey = false;
         break;
      case 'v':
      case 'V':
         subView = !subView;
         break;
      case 'c':
      case 'C':
         culling = !culling;
         break;
      case 'x':
      case 'X':
         moving = !moving;
         break;
   }*/
}

void GameEngine::handleMouseDown(int button, int mouseX, int mouseY) {
   if (button == 1) {
      mouseLeft = true;
   }
   
   if (button == 3) {
      mouseRight = true;
   }
}

void GameEngine::handleMouseMove(int mouseX, int mouseY) {
   if (mouseLeft) {
      m_camera->rotLocal(-mouseY/2.5, mouseX/2.5);
   }
   if (mouseRight) {
      m_displayObj->rotate(mouseY/2.5, -mouseX/2.5);
   }
}

void GameEngine::handleMouseUp(int button, int mouseX, int mouseY) {
   if (button == 1) {
      mouseLeft = false;
   }
   if (button == 3) {
      mouseRight = false;
   }
}
