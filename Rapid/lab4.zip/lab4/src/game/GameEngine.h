#ifndef StarRepub_GameEngine_h
#define StarRepub_GameEngine_h

#include "../engine/Interfaces.h"
#include "../engine/Camera.h"
#include "DisplayObj.h"

#ifdef __APPLE__
#include <SDL/SDL.h>
#include <SDL/SDL_opengl.h>
#endif

#ifdef __unix__
#include <SDL/SDL.h>
#include <SDL/SDL_opengl.h>
#endif

#ifdef _WIN32
#include <SDL.h>
#include <SDL_opengl.h>
#endif

#define BALLOON_SPAWN_RATE 500
#define BALLOON_AREA 80
#define FPS_UPDATE 2000

class GameEngine : public IGameEngine {
public:
   GameEngine(Modules *modules);
   ~GameEngine();
   void tic(unsigned int td);
   void render();
   
   void handleKeyDown(const char *k);
   void handleKeyUp(const char *k);
   void handleMouseDown(int button, int mouseX, int mouseY);
   void handleMouseMove(int mouseX, int mouseY);
   void handleMouseUp(int button, int mouseX, int mouseY);
   
private:
   list<IObject3d *> m_objects;
   Camera *m_camera;
   DisplayObj *m_displayObj;
   Modules *m_modules;
   //bool upkey, downkey, leftkey, rightkey;
   bool mouseLeft, mouseMiddle, mouseRight;
   bool moving;
   ivec2 m_lastLeftMouseLoc;
   ivec2 m_lastRightMouseLoc;
   string m_fps;
   unsigned int frameCount;
   unsigned int timeElapsed;
};

#endif
