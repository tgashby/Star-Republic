//
//  TestWorldGrid.cpp
//  StarRepublic
//
//  Created by Taggart Ashby on 2/25/12.
//  Copyright (c) 2012 476 Proj. All rights reserved.
//

// Tests are in seperate files

#include <UnitTest++/UnitTest++.h>

int main()
{
   return UnitTest::RunAllTests();
}