#include <vector>
#include "../src/game/World.h"
#include "../src/game/WorldPoint.h"
#include <assert.h>
#include <iostream>

class testWorld {
 public:
  void testLoop1();
  void testPath1();
  void testPoints1();
  int main();
 private:
};
